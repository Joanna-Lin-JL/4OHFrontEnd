//
//  NetworkManager.swift
//  Hackathon2022
//
//  Created by Joanna Lin on 4/27/22.
//

import Foundation
import Alamofire

class NetworkManager{
    static let host = "host"

    static func getAllOHs(completion: @escaping ([OH]) -> Void) {
        let endpoint = "\(host)"
        
        AF.request(endpoint, method: .get).validate().responseData { response in
            //process the response
            switch (response.result){
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode([OH].self, from: data){
                    completion(userResponse)
                }
                else{
                    print ("Failed to decode getAllOHs")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
            
        }
    }
    
    static func getTAOHs(taname: String, completion: @escaping ([OH]) -> Void) {
        let endpoint = "\(host)"
        AF.request(endpoint, method: .get).validate().responseData { response in
            //process the response
            switch (response.result){
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
           
                if let userResponse = try? jsonDecoder.decode([OH].self, from: data){
                    completion(userResponse)
                }
                else{
                    print ("Failed to decode getSpecificOH")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
            
        }
    }
    
    static func getSpecificOHs(coursename: String, completion: @escaping ([OH]) -> Void) {
        let endpoint = "\(host)"
        //TODO: don't know how
        
        AF.request(endpoint, method: .get).validate().responseData { response in
            //process the response
            switch (response.result){
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
           
                if let userResponse = try? jsonDecoder.decode([OH].self, from: data){
                    completion(userResponse)
                }
                else{
                    print ("Failed to decode getSpecificOH")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
            
        }
    }
    
    static func createOH(taname: String, coursename: String, dayofweek: String, start: String, end: String, location: String, completion: @escaping (OH) -> Void) {
        let endpoint = "\(host)"
        let params: [String: String] = [
            "taname": taname,
            "dayofweek": dayofweek,
            "start": start,
            "end": end,
            "location": location
        ]
        
        AF.request(endpoint, method: .post, parameters: params, encoder: JSONParameterEncoder.default).validate().responseData { response in
            //process the response
            switch (response.result){
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(OH.self, from: data){
                    completion(userResponse)
                }
                else{
                    print ("Failed to decode createOH")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
            
        }
    
        
        
    }
    
    static func updateOH(id: String, coursename: String, dayofweek: String, start: String, end: String, location: String, completion: @escaping (OH) -> Void) {
        let endpoint = "\(host)"
        let params: [String: String] = [
            "id": id,
            "dayofweek": dayofweek,
            "start": start,
            "end": end,
            "location": location
        ]
        AF.request(endpoint, method: .put, parameters: params, encoder: JSONParameterEncoder.default).validate().responseData { response in
            //process the response
            switch (response.result){
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(OH.self, from: data){
                    completion(userResponse)
                }
                else{
                    print ("Failed to decode updateOH")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
            
        }
    }
    
    static func updateAttendance(id: String, attendance: String, completion: @escaping (OH) -> Void) {
        let endpoint = "\(host)"
        let params: [String: String ] = [
            "id": id,
            "attendance": attendance
        ]
        AF.request(endpoint, method: .put, parameters: params, encoder: JSONParameterEncoder.default).validate().responseData { response in
            //process the response
            switch (response.result){
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(OH.self, from: data){
                    completion(userResponse)
                }
                else{
                    print ("Failed to decode updateOH")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
            
        }
    }
    
    static func deleteOH(id: String, taname: String, completion: @escaping (OH) -> Void) {
        let endpoint = "\(host)"
        print(id)
        print(taname)
        let params: [String: String] = [
            "id": id,
            "taname": taname
        ]
        AF.request(endpoint, method: .delete, parameters: params, encoder: JSONParameterEncoder.default).validate().responseData { response in
            //process the response
            switch (response.result){
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(OH.self, from: data){
                    completion(userResponse)
                }
                else{
                    print ("Failed to decode deletePost")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
            
        }
    }
    

//    static func getPostersOHs(poster: String, completion: Any) {
//
//    }
    
}


