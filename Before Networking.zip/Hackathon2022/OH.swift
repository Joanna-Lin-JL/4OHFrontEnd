//
//  OH.swift
//  Hackathon2022
//
//  Created by Joanna Lin on 4/26/22.
//

import Foundation

struct OH: Decodable, Encodable{
        let id: String
        let taname: String
        let coursename: String?
        let dayofweek: String?
        let start: String?
        let end: String?
        let location: String?
        let studentsattending: String
    
}

struct TAStudent: Decodable, Encodable{
    let id: String
    let name: String?
    let email: String
    let password: String
    let taornot: Bool
    let officehr: [OH]?
    //This is the oh they are attending for student and the oh they are hosting for the ta
}


