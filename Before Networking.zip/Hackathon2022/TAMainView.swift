//
//  TAMainView.swift
//  Hackathon2022
//
//  Created by Joanna Lin on 4/26/22.
//

import UIKit

protocol TAMVProtocol{
    func viewDidLoad()
    func save(id: String, taname: String, coursename: String, dayofweek: String, starthr: String, endhr: String, location: String)
}

class TAMainView: UIViewController, TAMVProtocol {
   
    

    var ohs: [OH] = []
    var chosen = -1
    var parentController: LIVProtocol?
    
    init(ohs: [OH]?){
        super.init(nibName:nil, bundle:nil)
        if let officehour = ohs{
            self.ohs = officehour
            ohtable.reloadData()
        }
    }
    
    init(){
        super.init(nibName:nil, bundle:nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var ohtable: UITableView = {
        let tableView = UITableView()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(TAViewOH.self, forCellReuseIdentifier: TAViewOH.id)
        tableView.isScrollEnabled = true
        return tableView
    }()
    
    var logout: UIButton = {
       let button = UIButton()
        button.addTarget(self, action: #selector(logoutpressed), for: .touchUpInside)
        button.setTitleColor(UIColor(red: 1, green: 0, blue: 0, alpha: 1), for: .normal)
        button.backgroundColor = .white
        button.setTitle("Log out", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .regular)
        button.titleLabel?.frame = CGRect(x: 0, y: 0, width: 58, height: 19)
        return button
    }()
    
    var yourOHs: UILabel = {
        let label = UILabel()
        label.text = "Your Current OH"
//        label.font = UIFont (name: "SFPro-Medium", size: 20)
        label.font = .systemFont(ofSize: 20, weight: .bold)
        label.frame = CGRect(x: 0, y: 0, width: 162, height: 24)
        label.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
        return label
    }()
    
    var createOHbutton: UIButton = {
        let button = UIButton()
         button.addTarget(self, action: #selector(createohpressed), for: .touchUpInside)
         button.backgroundColor = UIColor(red: 0, green: 0.58, blue: 1, alpha: 1)
         button.frame = CGRect(x: 0, y: 0, width: 102, height: 27)
         button.layer.cornerRadius = 15
         button.setTitle("+ Create OH", for: .normal)
         button.setTitleColor(.white, for: .normal)
         button.titleLabel?.font = .systemFont(ofSize: 16, weight: .regular)
         return button
    }()
    
    @objc func logoutpressed(){
        ohs = []
        print("pressed")
        navigationController?.popViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        let oh1 = OH(id: "1234",taname: "HEY", coursename: "CS2110", dayofweek: "Monday", start: "01:00", end: "02:00", location: "Rhodes", studentsattending: "1")
        let oh2 = OH(id: "1234",taname: "HI", coursename: "CS2222", dayofweek: "Friday", start: "02:00", end: "05:00", location: "Bard", studentsattending: "2")
        let oh3 = OH(id: "1234",taname: "HELLO", coursename: "CS3923", dayofweek: "Thursday", start: "11:00", end: "02:00", location: "Thurston", studentsattending: "3")
        let oh4 = OH(id: "1234",taname: "WASSUP", coursename: "CS3823", dayofweek: "Tuesday", start: "03:00", end: "04:00", location: "Duffield", studentsattending: "4")

        ohs = [oh1, oh2, oh3, oh4]

        [ohtable, yourOHs, logout, createOHbutton].forEach { views in
            views.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(views)
        }
        setupconstraints()

        // Do any additional setup after loading the view.
    }
    
    func sortoh(){
        
    }
    
    func setupconstraints(){
        
        NSLayoutConstraint.activate([
        
            yourOHs.topAnchor.constraint(equalTo: logout.bottomAnchor, constant: 50),
            yourOHs.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            yourOHs.heightAnchor.constraint(equalToConstant: 24),
            yourOHs.widthAnchor.constraint(equalToConstant: 162),
            
            createOHbutton.topAnchor.constraint(equalTo: yourOHs.bottomAnchor, constant: 59),
//            createOHbutton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 225),
            createOHbutton.heightAnchor.constraint(equalToConstant: 30),
            createOHbutton.widthAnchor.constraint(equalToConstant: 130),
            createOHbutton.trailingAnchor.constraint(equalTo: ohtable.trailingAnchor, constant: -30),
            
            logout.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: -17),
            logout.trailingAnchor.constraint(equalTo: createOHbutton.trailingAnchor),
            logout.heightAnchor.constraint(equalToConstant: 50),
            logout.widthAnchor.constraint(equalToConstant: 100),
            
            ohtable.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            ohtable.topAnchor.constraint(equalTo: createOHbutton.bottomAnchor, constant: 30),
            ohtable.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            ohtable.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 20)
            
        ])
        
    }
    
    @objc func createohpressed(){
        let editor = TAEditView()
        editor.editorcreate = "Create"
        editor.parentController? = self
        navigationController?.pushViewController(editor, animated: true)
    }
    
    
    
    func save(id: String, taname: String,coursename: String, dayofweek: String, starthr: String, endhr: String, location: String){
        
        if (chosen == -1){
            NetworkManager.createOH(taname: taname, coursename: coursename, dayofweek: dayofweek, start: starthr, end: endhr, location: location) { oh in
                
                self.ohs.append(oh)
                
//                self.shownPostData.append(newoh)
                self.ohtable.reloadData()

            }
            
        }
        else {
            NetworkManager.updateOH(id: id , coursename: coursename, dayofweek: dayofweek, start: starthr, end: endhr, location: location){ updatedoh in
                self.ohs[self.chosen] = updatedoh
                self.chosen = -1
                self.ohtable.reloadData()
            }
        }
        navigationController?.popToViewController(self, animated: true)
    }
}


    
    extension TAMainView: UITableViewDataSource {

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return ohs.count
        }


        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            if let cell = tableView.dequeueReusableCell(withIdentifier: TAViewOH.id, for: indexPath) as? TAViewOH {

                let i = ohs[indexPath.row]
                cell.configure(oh: i)
                cell.edit.tag = indexPath.row
                cell.edit.addTarget(self, action: #selector(editpressed(_:)), for: .touchUpInside)
                cell.delete.tag = indexPath.row
                cell.delete.addTarget(self, action: #selector(deletepressed(_:)), for: .touchUpInside)
                cell.selectionStyle = .none
                cell.backgroundColor = .clear
//                cell.layer.borderWidth = 1
//                cell.layer.cornerRadius = 10
//                cell.layer.shadowOpacity = 0.1
                //TODO: add the blue border and fix the shadow
//                cell.layer.shadowColor = UIColor(red: 0.175, green: 0.175, blue: 0.175, alpha: 1).cgColor
//                cell.layer.shadowOffset = .zero
                
                return cell
            } else {
                return UITableViewCell()
            }
        }
        
        @objc func editpressed(_ sender: UIButton){
            let editor = TAEditView()
            editor.parentController = self
            editor.originaloh = ohs[sender.tag]
            chosen = sender.tag
            present(editor, animated: true, completion: nil)
        }
        
        @objc func deletepressed(_ sender: UIButton){
            let originaloh = ohs[sender.tag]
            NetworkManager.deleteOH(id: originaloh.id, taname: originaloh.taname){ _ in
                self.ohs.removeAll { $0.id == originaloh.id }
                self.ohtable.reloadData()
            }
        }
    }




    extension TAMainView: UITableViewDelegate {
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 120
//            return UITableView.automaticDimension
        }

//        func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//            return UITableView.automaticDimension
//        }

//        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//            let editor = TAEditView()
//            editor.parentController = self
//            editor.originaloh = ohs[indexPath.item]
//            chosen = indexPath.row
//            present(editor, animated: true, completion: nil)
//        }

//        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//            if editingStyle == .delete {
//                ohs.remove(at: indexPath.row)
//            }
//        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


