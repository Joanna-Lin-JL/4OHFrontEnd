//
//  LoginManager.swift
//  Hackathon2022
//
//  Created by Joanna Lin on 5/4/22.
//

import Foundation
import Alamofire

struct LoginManager {
    static let host = "host"
    
    static func getUser(email: String, completion: @escaping (TAStudent) -> Void) {
        let endpoint = "\(host)"
        
        AF.request(endpoint, method: .get).validate().responseData { response in
            //process the response
            switch (response.result){
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
           
                if let userResponse = try? jsonDecoder.decode(TAStudent.self, from: data){
                    completion(userResponse)
                }
                else{
                    print ("Failed to decode getUser")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
            
        }
}
}
